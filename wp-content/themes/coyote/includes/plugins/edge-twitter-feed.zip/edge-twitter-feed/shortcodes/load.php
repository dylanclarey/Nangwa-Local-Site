<?php
//load lib
require_once 'lib/shortcode-interface.php';


//load shortcodes
require_once 'twitter-feed/twitter-feed.php';

//load shortcodes inteface
require_once 'lib/shortcode-loader.php';
